#include <inttypes.h>
#include <stdlib.h>
#include "ecran.h"
#include <string.h>
#include <stddef.h>
#include <cpu.h>

uint16_t CURSOR_POS = 0;
uint32_t curseur[2] = {1, 0};
uint16_t clignote = 0;
uint16_t couleur_fond = 0;
uint16_t couleur_texte = 15;
uint32_t n_lig = 25;
uint32_t n_col = 80;

uint16_t *ptr_mem(uint32_t lig, uint32_t col)
{
    uint16_t *ptr_mem = (uint16_t*) 0xB8000+(lig*80+col);
    return ptr_mem;
}

void ecrit_car(uint32_t lig, uint32_t col, char c){
    uint16_t *ptr = ptr_mem(lig, col);
    *ptr = (uint16_t)(c + (clignote << 15) + (couleur_fond << 12) + (couleur_texte << 8));
}

void efface_ecran(void){
    for(uint32_t i=0; i<n_lig; i++){
        for(uint32_t j=0; j<n_col; j++){
            ecrit_car(i, j, ' ');
        }
    }
}

void place_curseur(uint32_t lig, uint32_t col) {
    uint16_t pos = col + lig*80;
    uint8_t pos_h = (pos>>8);
    uint8_t pos_b = pos;
    outb(0x0F, 0x3D4);
    outb(pos_b, 0x3D5);
    outb(0x0E, 0x3D4);
    outb(pos_h, 0x3D5);
}

void traite_car(char c){

    if((c <= 31 && c>=0)|| c == 127){
        switch(c)
        {
            case '\b':
                if(curseur[1] != 0){
                    curseur[1]--;
                    place_curseur(curseur[0], curseur[1]);
                }
                break;
            case '\t':
                curseur[1]= (curseur[1]%8 + 1)*8;
                place_curseur(curseur[0], curseur[1]);
                break;
            case '\n':
                curseur[0]++;
                curseur[1]=0;
                place_curseur(curseur[0], curseur[1]);
                break;
            case '\f':
                efface_ecran();
                curseur[0]=0;
                curseur[1]=0;
                place_curseur(curseur[0], curseur[1]);
                break;
            case '\r':
                curseur[1]=0;
                place_curseur(curseur[0], curseur[1]);
                break;
            default:
                break;

        }
    }
    else{
        ecrit_car(curseur[0], curseur[1], c);
        if(curseur[1] >= 80){
            curseur[0]++;
            curseur[1]=0;
            place_curseur(curseur[0], curseur[1]);
        }
        else{
            curseur[1]++;
            place_curseur(curseur[0], curseur[1]);
        }
    }
}

void defilement(void){
    uint16_t lig;
    for(lig=1; lig < 24; lig++){
        memmove(ptr_mem(lig, 0), ptr_mem(lig+1, 0), 80 * sizeof(uint16_t));
    }
    lig = 24;
    for(uint16_t col = 0; col < 80; col ++){
        ecrit_car(lig, col,' ');
    }
}

void console_putbytes(char *chaine, int32_t taille){
    for(uint16_t i=0; i<taille; i++){
        if(curseur[0] > 24){
            defilement();
            curseur[0] = 24;
            curseur[1] = 0;
        }
        if(curseur[1] > 79){
            traite_car('\n');
        }
        traite_car(chaine[i]);
    }
}

#include "processus.h"
#include <stdio.h>
#include <cpu.h>

static int32_t free_pid = 0;

void fin_processus(void) {
    printf("fin_processus\n");
    tab_process[actif].etat = MORT;
    ordonnance();
}

static inline void dors(uint32_t nbr_secs) {
    tab_process[actif].wakeSecondes = nombres_secondes() + nbr_secs;
    tab_process[actif].etat = ENDORMI;
    sti();
    hlt();
    cli();
}

int32_t creer_process(void (*fct)(void), char *nom) {
    if(free_pid >= COUNT_OF_PROCESS) {
       return -1;
    } else {
       tab_process[free_pid].pid = free_pid;
       strcpy(tab_process[free_pid].nom, nom);
       tab_process[free_pid].etat = ACTIVABLE;
       tab_process[free_pid].z_save[1] = (int) &(tab_process[free_pid].pile_process[PILE_PROCESS_SIZE -2]);
       tab_process[free_pid].pile_process[PILE_PROCESS_SIZE - 2] = (int) fct;
       tab_process[free_pid].pile_process[PILE_PROCESS_SIZE - 1] = (int) fin_processus;

       return (free_pid++);
    }
}

void idle(void)
{
    for (;;) {
        printf("[%s] pid = %i\n", mon_nom(), mon_pid());
        // On entre dans une zone interruptible
        sti();
        hlt();
        cli();
    }
}

void proc1(void)
{
    for (int32_t i = 0; i < 2; i++) {
        printf("[temps = %u] processus %s pid = %i\n",
                nombres_secondes(),
                mon_nom(),
                mon_pid()
              );
        dors(1);
    }
}


void proc2(void)
{
    for (int32_t i = 0; i < 2; i++) {
        printf("[temps = %u] processus %s pid = %i\n",
                nombres_secondes(),
                mon_nom(),
                mon_pid()
              );
        dors(3);
    }
}

void proc3(void)
{
    for (int32_t i = 0; i < 2; i++) {
        printf("[temps = %u] processus %s pid = %i\n",
                nombres_secondes(),
                mon_nom(),
                mon_pid()
              );
        dors(5);
    }
}

int32_t findNextActif() {
    int32_t pid = actif + 1;
    while (pid%COUNT_OF_PROCESS != actif) {
        pid = pid % COUNT_OF_PROCESS;
        if(tab_process[pid].etat == ACTIVABLE) {
            return pid;
        }
        pid++;
    }
    return actif;
}

void wakeProcesses() {
    for(int32_t pid = 0; pid < COUNT_OF_PROCESS; pid++) {
        if(tab_process[pid].etat == ENDORMI && tab_process[pid].wakeSecondes < nombres_secondes()) {
            tab_process[pid].etat = ACTIVABLE;
        } else if(tab_process[pid].etat == ELU) {
            tab_process[pid].etat = ACTIVABLE;
        }
    }
}

void ordonnance() {
    int32_t old_actif = actif;
    wakeProcesses();
    actif = findNextActif();
    tab_process[actif].etat = ELU;
    ctx_sw(tab_process[old_actif].z_save,tab_process[actif].z_save);
}

char * mon_nom() {
    return tab_process[actif].nom;
}

int32_t mon_pid() {
    return actif;
}

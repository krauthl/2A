#ifndef __PROCESSUS_H__
#define __PROCESSUS_H__

#define PILE_PROCESS_SIZE 512
#define COUNT_OF_PROCESS 4
#define SIZE_NOM 128
enum state { ELU, ACTIVABLE, ENDORMI, MORT};

#include <inttypes.h>
#include "string.h"
#include "traitant.h"

int32_t actif;

void fin_processus();

struct processus {
    int pid;
    char nom[SIZE_NOM];
    enum state etat;
    int z_save[5];
    int pile_process[PILE_PROCESS_SIZE];
    uint32_t wakeSecondes;
};

struct processus tab_process[COUNT_OF_PROCESS];

void ctx_sw(void * adresse_ancien_contexte, void * adresse_nouveau_contexte);

void idle(void);

int32_t creer_process(void (*code)(void), char *nom);

void proc1(void);
void proc2(void);
void proc3(void);

void ordonnance();

char * mon_nom();

int32_t mon_pid();

uint32_t nombres_secondes();

#endif

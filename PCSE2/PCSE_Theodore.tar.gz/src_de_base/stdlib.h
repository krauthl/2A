#ifndef STDLIB_H_
#define STDLIB_H_

long int strtol(const char *nptr, char **endptr, int base);
unsigned long int strtoul(const char *nptr, char **endptr, int base);

#endif /*STDLIB_H_*/

#include <inttypes.h>
#include "ecran.h"
#include "cpu.h"
#include "stdio.h"
#include "stdbool.h"
#include "traitant.h"
#include "segment.h"
#include "processus.h"

uint32_t hou = 0;
uint32_t min = 0;
uint32_t sec = 0;
uint8_t cpt_tics_horloge = 0;
uint32_t comptes_secondes = 0;

uint32_t nombres_secondes() {
    return comptes_secondes;
}

void increment_time() {
    if (++sec >= 60) {
        sec = 0;
        if(++min >= 60) {
            min = 0;
            if(++hou >= 24) {
                hou = 0;
            }
        }
    }
    comptes_secondes++;
    char str[8];
    sprintf(str, "%u:%u:%u", hou, min, sec);
    ecrit_heure(str);
}

void ecrit_heure(char * str_hour) {
  ecrit_car(0, 0, str_hour[0]);
  ecrit_car(0, 1, str_hour[1]);
  ecrit_car(0, 2, str_hour[2]);
  ecrit_car(0, 3, str_hour[3]);
  ecrit_car(0, 4, str_hour[4]);
  ecrit_car(0, 5, str_hour[5]);
  ecrit_car(0, 6, str_hour[6]);
  ecrit_car(0, 7, str_hour[7]);
}

void tic_PIT() {
    outb(0x20, 0x20);
    cpt_tics_horloge++;
    if(cpt_tics_horloge >= 50) {
        cpt_tics_horloge = 0;
        increment_time();
    }
    ordonnance();
}

void init_traitant_IT(int32_t num_IT, void (*traitant)(void)) {
  uint32_t * table = (uint32_t *) 0x1000;
  uint32_t first_word = KERNEL_CS << 16;
  first_word |= ((uint32_t) traitant & 0x0000FFFF);
  uint32_t second_word = (uint32_t) traitant;
  second_word &= 0xFFFF0000;
  second_word |= 0x8E00;
  *(table + num_IT*2) = first_word;
  *(table + num_IT*2 + 1) = second_word;
}

void masque_IRQ(uint32_t num_IRQ, bool masque) {
    uint8_t inbut = inb(0x21);
    inbut &= (1<<num_IRQ) ^0xFF;
    inbut |= masque << num_IRQ;
    outb(inbut, 0x21);
}

#ifndef __TRAITANT_H__
#define __TRAITANT_H__

#include "stdbool.h"
uint32_t nombres_secondes();

void increment_time();

void ecrit_heure(char *);
void tic_PIT();

void init_traitant_IT(int32_t num_IT, void (*traitant)(void));

void masque_IRQ(uint32_t num_IRQ, bool masque);
#endif


import java.util.*;

/**
 * Classe des environnements. Un environnement associe à des chaînes de
 * caractères des double.
 */

class Env {

    // Un environnement est codé à l'aide d'une table associative
    // qui associe des double à des chaînes de caractères.
    private Map<String, Double> table;

    /**
     * Constructeur.
     */
    public Env() {
        table = new Hashtable<String, Double>();
    }

    /**
     * Associe la valeur val à la chaine s.
     */
    public void associer(String s, double val) {
        table.put(s, val); // Autoboxing (conversion double -> Integer
                           // implicite)
    }

    /**
     * Récupère la valeur associée à la chaine s. Lève une exception si s n'est
     * pas connue dans l'environnement.
     */
    public double obtenirValeur(String s) {
        if (contient(s)) {
            return table.get(s); // Autoboxing (conversion Integer -> int
                                 // implicite)
        } else {
            throw new RuntimeException("variable " + s
                    + " inconnue dans l'environnement");
        }
    }

    public boolean contient(String s) {
        return table.containsKey(s);
    }

    @Override
    public String toString() {
        return "Environnement : " + table;
    }
}



/*
 * Un exemple de solution, avec uniquement la methode toStringInfixe().
 *
 * TROIS solutions sont proposees:
 *  1. Methode "naive", mise en oeuvre sur les expressions unaires
 *     la methodetoStringInfixe n'est *PAS* redefinie au niveau de ExpUnaire
 *     Il y a du code "duplique" dans toutes les filles...
 *
 *  => le but est donc de factoriser la partie "commune" au niveau de ExpUnaire
 *
 *  2. Solution avec attribut, sur les expressions binaires
 *
 *  3. Solution avec methode abstraite (sur les expressions binaires, commentee)
 *
 */


//=========================================================================
abstract class ExpAbstraite {

    abstract public String toStringInfixe();

    @Override
    public String toString() {
        return "Je suis une expression et voila ma représentation infixée => "
            + toStringInfixe();
    }

    /**
     * Evalue cette expression dans l'environnement env et retourne sa valeur
     * double Lève une RunTimeException si une variable apparaissant dans cette
     * expression n'a pas de valeur dans env.
     */
    // TODO!
    //	abstract public double evaluer(Env env);
}


//=========================================================================
class Constante extends ExpAbstraite {
    double val;

    public Constante(double val) {
        this.val = val;
    }

    @Override
    public String toStringInfixe() {
        return Double.toString(val); // ou grosse triche "" + val;
    }
}


//=========================================================================
class Variable extends ExpAbstraite {
    String nom;

    public Variable(String nom) {
        this.nom = nom;
    }

    @Override
    public String toStringInfixe() {
        return nom;
    }
}



//=========================================================================
// Solution 1: naive (sur les unaires)
//=========================================================================
//  Ici toStringInfixe() n'est *PAS* redefinie au niveau de ExpUnaire
//	=> tout dans les filles, avec de la "redondance"
//=========================================================================
abstract class ExpUnaire extends ExpAbstraite {
    protected ExpAbstraite operande;	// protected, pour les filles

    public ExpUnaire(ExpAbstraite e) {
        operande = e;
    }
}


class UnaireCos extends ExpUnaire {
    public UnaireCos(ExpAbstraite e) {
        super(e);
    }

    @Override
    public String toStringInfixe() {
        return "cos(" + operande.toStringInfixe() + ")";	// redondance?
    }
}


class UnaireSin extends ExpUnaire {
    public UnaireSin(ExpAbstraite e) {
        super(e);
    }

    public String toStringInfixe() {
        return "sin(" + operande.toStringInfixe() + ")";	// redondance?
    }
}



//=========================================================================
// Solution 2 (sur les binaires)
//=========================================================================
// Ici l'affichage utilise une String representant l'operateur,
// initialisee par les constructeurs des filles.
// toStringInfixe() peut donc etre ecrite une seule fois dans ExpBinaire
//=========================================================================

abstract class ExpBinaire extends ExpAbstraite {
    // operandes
    private ExpAbstraite opGauche;	// private, plus besoin de protected!
    private ExpAbstraite opDroite;

    // Chaine representant l'operateur de cette exp binaire
    private String imageOperateur;

    public ExpBinaire(ExpAbstraite g, ExpAbstraite d, String imageOperateur) {
        opGauche = g;
        opDroite = d;
        this.imageOperateur = imageOperateur;
    }

    @Override
    public String toStringInfixe() {
        return "(" + opGauche.toStringInfixe() +
            " " + imageOperateur + " "			// on utilise l'image
            + opDroite.toStringInfixe() + ")";
    }
}


//=========================================================================
class BinaireMult extends ExpBinaire {

    public BinaireMult(ExpAbstraite g, ExpAbstraite d) {
        super(g, d, "*");	// init avec la chaine adequate
    }
}

//=========================================================================
class BinairePlus extends ExpBinaire {

    public BinairePlus(ExpAbstraite g, ExpAbstraite d) {
        super(g, d, "+");	// init avec la chaine adequate
    }
}




//=========================================================================
// Solution 3: avec methode abstraite
//=========================================================================
// Ici l'affichage utilise une methode abstraite qui retourne une chaine
// representant l'operateur.
// Cette methode doit etre redefinie par les filles.
// toStringInfixe() peut donc etre ecrite une seule fois dans ExpBinaire
//=========================================================================

/*
abstract class ExpBinaire extends ExpAbstraite {
    // operandes
    private ExpAbstraite opGauche;	// private, plus besoin de protected!
    private ExpAbstraite opDroite;

    public ExpBinaire(ExpAbstraite g, ExpAbstraite d) {
        opGauche = g;
        opDroite = d;
    }

    // On introduit une nouvelle methode retournant une image de l'operateur
    abstract protected String getImageOperateur();

    @Override
    public String toStringInfixe() {
        return "(" + opGauche.toStringInfixe()
                + " " + getImageOperateur() + " "		// on utilise la methode
                + opDroite.toStringInfixe() + ")";
    }
}


//=========================================================================
class BinaireMult extends ExpBinaire {

    public BinaireMult(ExpAbstraite g, ExpAbstraite d) {
        super(g, d);
    }

    @Override
    protected String getImageOperateur() {
        return "*";
    }
}

//=========================================================================
class BinairePlus extends ExpBinaire {

    public BinairePlus(ExpAbstraite g, ExpAbstraite d) {
        super(g, d);
    }

    @Override
    protected String getImageOperateur() {
        return "*";
    }
}
*/	// Fin de la solution 3
